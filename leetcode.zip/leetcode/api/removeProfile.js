import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

const ADMIN_PASSWORD = "147069"; // move to env var in real projects

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  try {
    const { username, password } = req.body;

    if (password !== ADMIN_PASSWORD) {
      return res.status(403).json({ error: "Forbidden" });
    }

    const { error } = await supabase
      .from("profiles")
      .delete()
      .eq("username", username);

    if (error) throw error;

    return res.status(200).json({ message: "User deleted successfully" });
  } catch (err) {
    console.error("Remove error:", err);
    return res.status(500).json({ error: "Failed to remove user." });
  }
}
