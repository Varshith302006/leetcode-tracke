import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

const getGraphQLQuery = (username) => ({
  query: `
    query {
      matchedUser(username: "${username}") {
        username
        profile {
          ranking
        }
        submitStats: submitStatsGlobal {
          acSubmissionNum {
            difficulty
            count
          }
        }
      }
      recentSubmissionList(username: "${username}") {
        status
        timestamp
      }
    }
  `,
});

const getISTMidnight = () => {
  const now = new Date();
  const istOffset = 330 * 60 * 1000;
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  const istNow = new Date(utc + istOffset);
  istNow.setUTCHours(0, 0, 0, 0);
  return istNow.getTime();
};

export default async function handler(req, res) {
  try {
    const todayMidnightIST = getISTMidnight();

    // ✅ Fetch from Supabase
    const { data: userProfiles, error } = await supabase
      .from("profiles")
      .select("*");

    if (error) {
      console.error("Supabase Error:", error);
      return res.status(500).json({ error: "Failed to fetch users from Supabase." });
    }

    const results = await Promise.all(
      userProfiles.map(async ({ username, nickname }) => {
        const leetRes = await fetch("https://leetcode.com/graphql", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(getGraphQLQuery(username)),
        });

        const json = await leetRes.json();

        if (!leetRes.ok || json.errors) {
          throw new Error(`Failed to fetch LeetCode data for ${username}`);
        }

        const { data } = json;
        const userData = data.matchedUser;
        const acStats = userData?.submitStats?.acSubmissionNum || [];

        const totalSolved = acStats.find(d => d.difficulty === "All")?.count || 0;
        const easySolved = acStats.find(d => d.difficulty === "Easy")?.count || 0;
        const mediumSolved = acStats.find(d => d.difficulty === "Medium")?.count || 0;
        const hardSolved = acStats.find(d => d.difficulty === "Hard")?.count || 0;

        const recent = data.recentSubmissionList || [];
        const todaySolved = recent.filter(r => {
          const ts = Number(r.timestamp) * 1000;
          return r.status === "AC" && ts >= todayMidnightIST;
        }).length;

        return {
          username,
          nickname: nickname || username,
          totalSolved,
          easySolved,
          mediumSolved,
          hardSolved,
          todaySolved,
          rank: userData?.profile?.ranking || null,
        };
      })
    );

    return res.status(200).json(results);
  } catch (err) {
    console.error("Function Error:", err);
    return res.status(500).json({ error: err.message });
  }
}
