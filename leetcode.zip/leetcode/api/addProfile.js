import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  try {
    const { username, nickname } = typeof req.body === "string"
      ? JSON.parse(req.body)
      : req.body;

    if (!username) {
      return res.status(400).json({ error: "Username is required" });
    }

    const { data: existing, error: existsErr } = await supabase
      .from("profiles")
      .select("*")
      .eq("username", username)
      .maybeSingle();

    if (existsErr) throw existsErr;

    if (existing) {
      return res.status(400).json({ error: "User already exists" });
    }

    const { error } = await supabase.from("profiles").insert([
      {
        username,
        nickname: nickname || username,
      },
    ]);

    if (error) throw error;

    return res.status(200).json({ message: "User added successfully" });
  } catch (err) {
    console.error("Add Profile Error:", err.message || err);
    return res.status(500).json({ error: err.message || "Failed to add user" });
  }
}
