import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";

const SUPABASE_URL = "https://xjvygwwvubnbcervgoos.supabase.co"; // from Supabase
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhqdnlnd3d2dWJuYmNlcnZnb29zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMxMjY4MTgsImV4cCI6MjA2ODcwMjgxOH0.jYkjp9R_sud694OgCe29ZDjd_kkObTh6htJNmVCN6uw"; // from Supabase

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);




// Theme Toggle
const toggleBtn = document.getElementById("theme-toggle");

function applyTheme(theme) {
  const isLight = theme === "light";
  document.body.classList.toggle("light-theme", isLight);
  if (toggleBtn) toggleBtn.textContent = isLight ? "🌞" : "🌙";
}

function initTheme() {
  const storedTheme = localStorage.getItem("theme");
  const theme =
    storedTheme ||
    (window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark");
  applyTheme(theme);
}

if (toggleBtn) {
  toggleBtn.addEventListener("click", () => {
    const isLight = document.body.classList.toggle("light-theme");
    const newTheme = isLight ? "light" : "dark";
    localStorage.setItem("theme", newTheme);
    toggleBtn.textContent = isLight ? "🌞" : "🌙";
  });
}

initTheme();

document.getElementById("addProfileBtn").addEventListener("click", addNewProfile);


// Load LeetCode User Data
async function loadData() {
  try {
    const res = await fetch("/api/getUsers");
    const data = await res.json();

    console.log("Raw API Response:", data);

    if (!Array.isArray(data)) {
      throw new Error("API returned invalid data structure");
    }

    const tbody = document.getElementById("userBody");
    tbody.innerHTML = "";

    data
      .sort((a, b) => (a.nickname || a.username).localeCompare(b.nickname || b.username))
      .forEach((user) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td><a href="https://leetcode.com/${user.username}" target="_blank">${user.nickname || user.username}</a></td>
        <td>${user.totalSolved}</td>
        <td>${user.rank ?? "N/A"}</td>
        <td>${user.easySolved}</td>
        <td>${user.mediumSolved}</td>
        <td>${user.hardSolved}</td>
        <td><button onclick="removeProfile('${user.username}')">❌</button></td>
      `;
      tbody.appendChild(row);
    });
  } catch (err) {
    console.error("API Error:", err);
    alert("Failed to load data. Please try again later.");
  }
}

async function addNewProfile() {
  const username = document.getElementById("newUsername").value.trim();
  const nickname = document.getElementById("newNickname").value.trim();

  if (!username) {
    alert("Username is required");
    return;
  }

  const res = await fetch("/api/addProfile", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",  // 🔥 Required for JSON body
    },
    body: JSON.stringify({ username, nickname }),
  });


  const result = await res.json();
  alert(result.message || result.error);

  if (res.ok||!res.ok) {
    document.getElementById("newUsername").value = "";
    document.getElementById("newNickname").value = "";
    loadData();
  }
}



async function removeProfile(username) {
  const password = prompt("Enter admin password to delete this profile:");
  if (password !== "147069") {
    alert("Incorrect password. Profile not removed.");
    return;
  }

  try {
    const res = await fetch("/api/removeProfile", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username, password }),
    });

    const result = await res.json();

    if (res.ok) {
      alert("Profile removed.");
      loadData();
    } else {
      alert("Failed to remove: " + result.error);
    }
  } catch (err) {
    console.error("Remove error:", err);
    alert("Error removing profile.");
  }
}



loadData();
window.removeProfile = removeProfile;
